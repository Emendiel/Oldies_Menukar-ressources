<?php

readfile('php://input');